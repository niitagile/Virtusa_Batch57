package Polymorphism;
class Stud{
	public void display(){
		System.out.println("I am Stud Class Method");
	}
}
class Res extends Stud{
	@Override
	public void display(){
		System.out.println("I am Res Class Method");
	}
	public void show(){
		System.out.println("show method");
	}
}
public class DispatchingExample {
	public static void main(String[] args) {
		
		Stud ptr;
		ptr=new Res();
		ptr.display();
		//ptr.show(); error 
		
		ptr=new Stud();
		ptr.display();
		
		
	}

}
