package Polymorphism;
//Method shadowing or method hiding
class ParentB{
	static void display(){
		System.out.println("Parent method");
	}
}
class ChildB extends ParentB{
	//@Override
	static void display(){
		System.out.println("child method");
	}
	void show(){
		super.display();
	}
}
public class staticMethodOverride {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
