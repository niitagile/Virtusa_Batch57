package Polymorphism;
class Parent{
	public void display(){
		System.out.println("Parent's Method");
	}
}
class Child extends Parent{
	@Override
	public void display(){
		super.display();
		System.out.println("Child's Method");
	}
}
public class MethodOverriding1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Child child=new Child();
		child.display();
	}

}
