package Polymorphism;
class ParentA{
	void display(){
		System.out.println("ParentA Method");
	}
}
class ChildA extends ParentA{
	@Override// annotation - an instruction given to compiler
	void display(){
		System.out.println("ChildA Method");
		//super.display();
	}
	void show(){}
}

public class MethodOveriding {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//ChildA obj =new ChildA();
		//obj.display();
		ParentA ptr;
		ptr=new ChildA();
		ptr.display();
		//ptr.show();
		ptr=new ParentA();
		ptr.display();

	}

}
