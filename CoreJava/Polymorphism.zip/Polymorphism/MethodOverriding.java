package Polymorphism;
class Person{
	
	Number show(){
		System.out.println("Person's show");
		return 34;
		}
}
class Student extends Person{
	
	@Override
	Integer show(){
		
		System.out.println("Student's show");
		return 12;
		}
	
}

public class MethodOverriding {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Person ptr=(Person)new Student();
			
			
			
	}

}
