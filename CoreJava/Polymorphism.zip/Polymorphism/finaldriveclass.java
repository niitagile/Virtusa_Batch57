package Polymorphism;
class Parent2{
	final public void display(){
		
	}
}
class Child2 extends Parent2{
	/*@Override final method can't be overriden
	public void display(){
		
	}*/
}
public class finaldriveclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
