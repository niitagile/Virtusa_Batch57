package Polymorphism;

public class Methodoverloading {

	public void area(int a){
		System.out.println("a="+a);
	}
	/*Duplicate method as no value of return type
	public int area(int a){
		System.out.println("a="+a);
	}*/
	public void area(double b){
		System.out.println("a="+b);
	}
	public void area(int a, float b){
		System.out.println("a="+a+"b="+b);
	}
	public void area(float a, int b){
		System.out.println("a="+a+"b="+b);
	}
	
	public static void main(String[] args) {
		Methodoverloading obj=new Methodoverloading();
		obj.area(5,8.9f);
		obj.area(7.8f,3);

	}

}
