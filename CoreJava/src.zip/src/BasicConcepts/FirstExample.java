package BasicConcepts;

public class FirstExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*System.out.println("We are Leraning Java!!!!");
		System.out.print("Hello All");
		System.out.println("Lets do fun!!!!");
		System.out.println(5+6);*/
		
	/*	byte a=8;
		byte b=4;
		byte c=(byte)(a+b);*/
		
		
		/*float a=4.5f;
		int b=6;
		System.out.println(a+b);//4.5f+6.0f implicit conversion*/
		
		/*int a=5; 
		int b=3; 
		int c=4;
		System.out.println(a>b && a>c);
		System.out.println(a>b & a>c);*/
		
		int a=5;
		int b=4;
		System.out.println((a>5 && ++b ==5 ));
		System.out.println(b);
		//System.out.println((a>5 & ++b ==5 ));

	}

}
