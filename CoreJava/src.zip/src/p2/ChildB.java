package p2;

import p1.Parent;

public class ChildB extends Parent{
	void display(){
		//method1(); private member can't be accessed
		// method2();  default
		method3();
		method4();
	}
}
