package p2;

import p1.Parent;

public class ClassB {
	void display(){
		Parent p=new Parent();
		//method1(); private member can't be accessed
		//p.method2(); default
		//p.method3(); protected
		p.method4();
	}

}
