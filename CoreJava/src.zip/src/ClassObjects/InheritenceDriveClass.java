package ClassObjects;
class Parent{
	int a;
	/*Parent(){
		System.out.println("Parent's Constructor");
	}*/
	Parent(int a){
		this.a=a;
	}
	void display(){
		System.out.println("a="+a);
	}
	
}
class Child extends Parent{
	Child(){
		super(5);// this must be the first line in constructor
		System.out.println("Child's Constructor");
	}
}
public class InheritenceDriveClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Child child=new Child();
		child.display();
	}

}
