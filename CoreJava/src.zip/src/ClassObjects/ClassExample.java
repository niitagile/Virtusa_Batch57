package ClassObjects;

import java.util.Scanner;

class Student{
	int rollno;
	String name;
	Student(){
		rollno=0;
		name=null;
	}
	Student(int r, String n){
		rollno=r;
		name=n;
	}
	void getInfo(){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter name");
		name=sc.nextLine();
		System.out.println("Enter rollno");
		rollno=sc.nextInt();
	}
	void display(){
		System.out.println("rollno="+rollno);
		System.out.println("name="+name);
	}
}
public class ClassExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student stud1=new Student(1,"Leena");
		stud1.display();
		stud1.getInfo();
		stud1.display();
		

	}

}
