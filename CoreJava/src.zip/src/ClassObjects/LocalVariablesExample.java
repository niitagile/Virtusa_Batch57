package ClassObjects;
class ClassB{
	String name;
	void getInfo(String name){
		this.name=name;
		int roll=3;
	}
	void display(){
		System.out.println("name="+name);
		//System.out.println("Rollno="+roll);
	}
}
public class LocalVariablesExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClassB obj=new ClassB();
		obj.getInfo("Shweta");
		obj.display();

	}

}
