package ClassObjects;
class ClassC{
	private int rollno;
	private String name;
	//getter
	int getRollno(){
		return this.rollno;
	}
	
	public String getName() {
		return name;
	}

	//setters
	void setRollno(int rollno){
		this.rollno=rollno;
	}
	public void setName(String name) {
		this.name = name;
	}
}
public class EncapsulationExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClassC obj=new ClassC();
		obj.setRollno(1);
		obj.setName("Kavita");
		System.out.println("Rollno="+obj.getRollno());
		System.out.println("name="+obj.getName());
	}

}
