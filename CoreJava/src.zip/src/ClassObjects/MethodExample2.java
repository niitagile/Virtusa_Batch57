package ClassObjects;
class ClassA{
	public  int square(int num){
		return num*num;
	}
	
	public  void display(String msg){
		System.out.println(msg);
	}
	
	char charReturn(String str){
		return str.charAt(0);
	}
}
public class MethodExample2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClassA obj=new ClassA();
		int ans=obj.square(5);
		System.out.println(ans);
		obj.display("Hello A!!!!");	

	}

}
