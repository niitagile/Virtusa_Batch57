package ClassObjects;

public class MethodExample {
	public static int square(int num){
		return num*num;
	}
	
	public static void display(String msg){
		System.out.println(msg);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
				int ans=square(5);
				System.out.println(ans);
				display("Hello A!!!!");	
	}

}
