package p1;

public class ChildA extends Parent {

	void display(){
		//method1(); private member can't be accessed
		method2();
		method3();
		method4();
	}
}
