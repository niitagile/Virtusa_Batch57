package p1;

public class ClassA {
	void display(){
		Parent p=new Parent();
		//method1(); private member can't be accessed
		p.method2();
		p.method3();
		p.method4();
	}
}
