package p1;

public class Parent {
	private void method1(){}
	void method2(){}
	protected void method3(){}
	public void method4(){}
}
