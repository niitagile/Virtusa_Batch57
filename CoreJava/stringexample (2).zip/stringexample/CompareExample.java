package stringexample;

public class CompareExample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Hello";
		String s1="hello";
		System.out.println(s.compareTo(s1)); 
		System.out.println(s.compareToIgnoreCase(s1));
	}

}
