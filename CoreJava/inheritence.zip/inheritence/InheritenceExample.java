package inheritence;

public class InheritenceExample {
	private int a=5;
	int b=8;
	protected int c=89;
	public int d=70;


}
