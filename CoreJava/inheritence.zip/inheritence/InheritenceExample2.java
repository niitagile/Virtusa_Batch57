package inheritence;
class InheritenceExample3 extends InheritenceExample{
	public void display(){
		//System.out.println("a="+a);
		System.out.println("b="+b);
		System.out.println("c="+c);
		System.out.println("d="+d);
	}
}
class InheritenceExample2 {
public void show(){
	InheritenceExample obj=new InheritenceExample();
	//System.out.println("a="+obj.a);
	System.out.println("b="+obj.b);
	System.out.println("c="+obj.c);
	System.out.println("d="+obj.d);
	
}
	

}
