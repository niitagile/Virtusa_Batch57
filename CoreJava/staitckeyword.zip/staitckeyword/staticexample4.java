package Classes;

class Class2{ 
static int count=0;//will get memory only once and retain its value 
	Class2(){ 
	count++; 
	System.out.println(count); 
	} 
	public static void main(String args[]){ 
	Class2 c1=new Class2(); 
	Class2 c2=new Class2(); 
	Class2 c3=new Class2(); 
	} 
	} 
